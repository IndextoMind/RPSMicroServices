using System;

class App
{

   static void Main(String[] args)
   {

     Console.WriteLine("Ready to compile c# without IDE!!!"); 

   }

}